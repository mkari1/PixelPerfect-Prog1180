//Clears the forms
function clearForm() {
    document.getElementById("equipmentForm").reset();
    document.getElementById('clearButton').reset(); // Hide the Clear button
}

// Function to register equipment
function registerEquipment(equipment) {
    // Retrieve the existing stored equipment from localStorage
    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];

    // Check for duplicates
    var isDuplicate = storedEquipment.some(function (storedItem) {
        return storedItem.serialNumber === equipment.serialNumber;
    });

    if (!isDuplicate) {
        // Add the new equipment to the array
        storedEquipment.push(equipment);

        // Save the updated equipment list back to localStorage
        localStorage.setItem('storedEquipment', JSON.stringify(storedEquipment));

        // Notify the user that the equipment was registered
        alert('Equipment successfully registered.');

        // Optionally, navigate to the equipment view page
        window.location.href = 'equipment-view.html'; // Replace 'equipment-view.html' with your actual page URL
    } else {
        // Notify the user that it's a duplicate
        alert('This serial number is already registered.');
    }
}

//EQUIPMENT REGISTRATION
function submitForm() {
    var equipmentName = document.getElementById("equipmentName").value;
    var model = document.getElementById("model").value;
    var colour = document.getElementById("colour").value;
    var serialNumber = document.getElementById("serialNumber").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var description = document.getElementById("description").value;

    // Perform validation here
    if (equipmentName.trim() === '') {
        alert('Equipment Name is required.');
        return false;
    }
    if (model.trim() === '') {
        alert('Model is required.');
        return false;
    }
    if (!/^\d{12}$/.test(serialNumber)) {
        alert('Serial Number must be a 12-character integer.');
        return;
    }
    if (equipmentType === 'Select Equipment Type') {
        alert('Please select an Equipment Type.');
        return false;
    }
    if (manufacturer === 'Select A Manufacturer') {
        alert('Please select a manufacturer.');
        return false;
    }

    var equipment = {
        equipmentName: equipmentName,
        model: model,
        colour: colour,
        serialNumber: serialNumber,
        equipmentType: equipmentType,
        manufacturer: manufacturer,
        description: description
    };

    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];
    storedEquipment.push(equipment);
    localStorage.setItem('storedEquipment', JSON.stringify(storedEquipment));

    document.getElementById("equipmentForm").reset();

    alert('Equipment successfully registered.');

    // Call the registerEquipment function with the equipment data
    registerEquipment(equipment);

    //Instead of navigating immediately, give some time (e.g., 3 second) for registration to complete
     setTimeout(function () {
    window.location.href = 'equipment-view.html';
}   , 3000);
}

var storedEquipment = [
    {
        equipmentName: 'MicroCut',
        model: 'HRN',
        colour: 'Red',
        serialNumber: '123456789098',
        type: 'Lawn Mower',
        manufacturer: 'Honda',
    },
    {
        equipmentName: '250',
        model: 'MS',
        colour: 'Orange',
        serialNumber: '789012456789',
        type: 'Chainsaw',
        manufacturer: 'Stihl',
        description: 'Designed for firewood cutting and around-the-home tasks with a great power-to-weight ratio.',
    },
];

//EQUIPMENT DETAILS
function loadEquipmentDetails() {
    var currentSerial = getSerialNumberFromURL();
    var currentEquipment = storedEquipment.find(function (equipment) {
        return equipment.serialNumber === currentSerial;
    });
    // There is no select equipment, show a blank form
    if(currentEquipment === undefined) 
        return;

    document.getElementById("equipmentName").value = currentEquipment.equipmentName;
    document.getElementById("model").value = currentEquipment.model;
    document.getElementById("colour").value = currentEquipment.colour;
    document.getElementById("serialNumber").value = currentEquipment.serialNumber;
    document.getElementById("equipmentType").value = currentEquipment.equipmentType;
    document.getElementById("manufacturer").value = currentEquipment.manufacturer;
    document.getElementById("description").value = currentEquipment.description;
}

function enableEditing() {
    // Enable editing of input fields and show the Update button
    document.querySelectorAll('input[type="text"], textarea').forEach(input => {
        input.removeAttribute('readonly');
    });
    // Show the "Clear" button
    document.getElementById('clearButton').style.display = 'block';
    
    // Hide the "Edit" button
    document.getElementById('editButton').style.display = 'none';
    
    // Show the "Update" button
    document.getElementById('updateButton').style.display = 'block';
}

function updateEquipment() {
    // Get the updated data from the form
    var equipmentName = document.getElementById("equipmentName").value;
    var model = document.getElementById("model").value;
    var colour = document.getElementById("colour").value;
    var serialNumber = document.getElementById("serialNumber").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var description = document.getElementById("description").value;

    // Validate the serial number format (must be an integer of 12 digits)
    if (equipmentName.trim() === '') {
        alert('Equipment Name is required.');
        return false;
    }
    if (model.trim() === '') {
        alert('Model is required.');
        return false;
    }
    if (!/^\d{12}$/.test(serialNumber)) {
        alert('Serial number must be a 12-digit integer.');
        return;
    }
    if (equipmentType === 'Select Equipment Type') {
        alert('Please select an Equipment Type.');
        return false;
    }
    if (manufacturer === 'Select A Manufacturer') {
        alert('Please select a manufacturer.');
        return false;
    }

    // Update the equipment details (you can save it to a database or perform any other desired action)
    var updatedEquipment = {
        equipmentName: equipmentName,
        model: model,
        colour: colour,
        serialNumber: serialNumber,
        equipmentType: equipmentType,
        manufacturer: manufacturer,
        description: description
    };

    // Replace the old equipment details with the updated details
    // You can save this to a database or update your storage mechanism as needed
    alert('Equipment details updated successfully!');

    // Disable editing and show the Edit button again
    document.querySelectorAll('input[type="text"], textarea').forEach(input => {
        input.setAttribute('readonly', 'readonly');
    });
    // After successfully updating the equipment, hide the "Clear" button
    document.getElementById('clearButton').style.display = 'none';
    
    // Show the "Edit" button
    document.getElementById('editButton').style.display = 'block';
    
    // Hide the "Update" button
    document.getElementById('updateButton').style.display = 'none';
}

function generateEquipmentTable() {
    var equipmentTable = document.querySelector('table');
    if(!equipmentTable)
        return;
    // Clear the table before populating it
    equipmentTable.innerHTML = '';

    // Loop through the stored equipment and add rows to the table
    storedEquipment.forEach(function (equipment) {
        var newRow = equipmentTable.insertRow(-1);
        var modelCell = newRow.insertCell(0);
        var typeCell = newRow.insertCell(1);
        var serialNumberCell = newRow.insertCell(2);

        var equipmentLink = document.createElement('a');
        equipmentLink.className = 'equipment-link';
        equipmentLink.href = 'equipment-details.html?serial=' + equipment.serialNumber;
        equipmentLink.textContent = equipment.model;

        modelCell.appendChild(equipmentLink);
        typeCell.textContent = equipment.type;
        serialNumberCell.textContent = equipment.serialNumber;
    });
}

// Call the function to generate the equipment table when the page loads
generateEquipmentTable();

// Function to retrieve the serial number from the URL parameter
function getSerialNumberFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('serial');
}

// Call the function to get the serial number
const serialNumber = getSerialNumberFromURL();

// EQUIPMENT VIEW
// Function to display stored equipment
function displayStoredEquipment() {
    var equipmentTable = document.querySelector('table');

    // Retrieve stored equipment from localStorage
    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];

    // Loop through the stored equipment and add rows to the table
    storedEquipment.forEach(function (equipment) {
        var newRow = equipmentTable.insertRow(-1); // -1 inserts a row at the end
        var modelCell = newRow.insertCell(0);
        var typeCell = newRow.insertCell(1);
        var serialNumberCell = newRow.insertCell(2);

        var equipmentLink = document.createElement('a');
        equipmentLink.className = 'equipment-link';
        equipmentLink.href = 'equipment-details.html?serialNumber=' + equipment.serialNumber;
        equipmentLink.textContent = equipment.model;

        modelCell.appendChild(equipmentLink);
        typeCell.textContent = equipment.equipmentType;
        serialNumberCell.textContent = equipment.serialNumber;

        // Store the equipment data as a dataset attribute for each row
        newRow.dataset.serialNumber = equipment.serialNumber;
        newRow.dataset.model = equipment.model;
        newRow.dataset.equipmentType = equipment.equipmentType;
    });
}

// Call the function when the page has fully loaded
window.onload = function () {
    displayStoredEquipment();
    loadEquipmentDetails();
};
// Function to clear all stored equipment
function clearStoredEquipment() {
    localStorage.removeItem('storedEquipment');
}

// Call this function to clear the storage
//clearStoredEquipment();
