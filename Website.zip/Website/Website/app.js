//Clears the forms
function clearForm() {
    document.getElementById("equipmentForm").reset();
    document.getElementById('clearButton').reset(); // Hide the Clear button
}

// Function to register equipment
function registerEquipment(equipment) {
    // Retrieve the existing stored equipment from localStorage
    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];

    // Check for duplicates
    var isDuplicate = storedEquipment.some(function (storedItem) {
        return storedItem.serialNumber === equipment.serialNumber;
    });

    if (!isDuplicate) {
        // Add the new equipment to the array
        storedEquipment.push(equipment);

        // Save the updated equipment list back to localStorage
        localStorage.setItem('storedEquipment', JSON.stringify(storedEquipment));

        // Notify the user that the equipment was registered
        alert('Equipment successfully registered.');

        // Optionally, navigate to the equipment view page
        window.location.href = 'equipment-view.html'; // Replace 'equipment-view.html' with your actual page URL
    } else {
        // Notify the user that it's a duplicate
        alert('This serial number is already registered.');
    }
}

//EQUIPMENT REGISTRATION
function submitForm() {
    var equipmentName = document.getElementById("equipmentName").value;
    var model = document.getElementById("model").value;
    var colour = document.getElementById("colour").value;
    var serialNumber = document.getElementById("serialNumber").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var description = document.getElementById("description").value;

    // Perform validation here
    if (equipmentName.trim() === '') {
        alert('Equipment Name is required.');
        return false;
    }
    if (model.trim() === '') {
        alert('Model is required.');
        return false;
    }
    if (!/^\d{12}$/.test(serialNumber)) {
        alert('Serial Number must be a 12-character integer.');
        return;
    }
    if (equipmentType === 'Select Equipment Type') {
        alert('Please select an Equipment Type.');
        return false;
    }
    if (manufacturer === 'Select A Manufacturer') {
        alert('Please select a manufacturer.');
        return false;
    }

    var equipment = {
        equipmentName: equipmentName,
        model: model,
        colour: colour,
        serialNumber: serialNumber,
        equipmentType: equipmentType,
        manufacturer: manufacturer,
        description: description
    };

    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];
    storedEquipment.push(equipment);
    localStorage.setItem('storedEquipment', JSON.stringify(storedEquipment));

    document.getElementById("equipmentForm").reset();

    alert('Equipment successfully registered.');

    // Call the registerEquipment function with the equipment data
    registerEquipment(equipment);

    //Instead of navigating immediately, give some time (e.g., 3 second) for registration to complete
     setTimeout(function () {
    window.location.href = 'equipment-view.html';
}   , 3000);
}
var storedEquipment = [
    {
        equipmentName: 'MicroCut',
        model: 'HRN',
        colour: 'red',
        serialNumber: '123456789098',
        equipmentType: 'lawnMower',
        manufacturer: 'honda',
    },
    {
        equipmentName: '250',
        model: 'MS',
        colour: 'orange',
        serialNumber: '789012456789',
        equipmentType: 'chainsaw',
        manufacturer: 'stihl',
        description: 'Designed for firewood cutting and around-the-home tasks with a great power-to-weight ratio.',
    },
    {
        equipmentName: 'Handheld Leaf Blower',
        model: 'MAX XR',
        colour: 'yellow',
        serialNumber: '012345678901',
        equipmentType: 'leafBlower',
        manufacturer: 'dewalt',
    },
];

//EQUIPMENT DETAILS
function loadEquipmentDetails() {
    var currentSerial = getSerialNumberFromURL();
    var currentEquipment = storedEquipment.find(function (equipment) {
        return equipment.serialNumber === currentSerial;
    });
    
    console.log(currentEquipment);
    // There is no select equipment, try the local storage
    if(currentEquipment === undefined) 
    {
        var localStorageEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];
        currentEquipment = localStorageEquipment.find(function (equipment) {
            return equipment.serialNumber === currentSerial;
        });
        console.log(currentEquipment);
    }

    // if(currentEquipment === undefined)
    // {
    //     alert(`Equipment not found with serial ${currentSerial}.`);
    //     return;
    // }

    document.getElementById("equipmentName").value = currentEquipment.equipmentName;
    // There is no select equipment, show a blank form
    if(currentEquipment === undefined) 
        return;

    document.getElementById("equipmentName").value = currentEquipment.equipmentName;
    document.getElementById("model").value = currentEquipment.model;
    document.getElementById("colour").value = currentEquipment.colour;
    document.getElementById("serialNumber").value = currentEquipment.serialNumber;
    document.getElementById("equipmentType").value = currentEquipment.equipmentType;
    document.getElementById("manufacturer").value = currentEquipment.manufacturer;
    
}

function enableEditing() {
    // Enable editing of input fields and show the Update button
    document.querySelectorAll('input[type="text"], textarea').forEach(input => {
        input.removeAttribute('readonly');
    });
    // Show the "Clear" button
    document.getElementById('clearButton').style.display = 'block';
    
    // Hide the "Edit" button
    document.getElementById('editButton').style.display = 'none';
    
    // Show the "Update" button
    document.getElementById('updateButton').style.display = 'block';
}

function updateEquipment() {
    // Get the updated data from the form
    var equipmentName = document.getElementById("equipmentName").value;
    var model = document.getElementById("model").value;
    var colour = document.getElementById("colour").value;
    var serialNumber = document.getElementById("serialNumber").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var description = document.getElementById("description").value;

    // Validate the serial number format (must be an integer of 12 digits)
    if (equipmentName.trim() === '') {
        alert('Equipment Name is required.');
        return false;
    }
    if (model.trim() === '') {
        alert('Model is required.');
        return false;
    }
    if (!/^\d{12}$/.test(serialNumber)) {
        alert('Serial number must be a 12-digit integer.');
        return;
    }
    if (equipmentType === 'Select Equipment Type') {
        alert('Please select an Equipment Type.');
        return false;
    }
    if (manufacturer === 'Select A Manufacturer') {
        alert('Please select a manufacturer.');
        return false;
    }

    // Update the equipment details (you can save it to a database or perform any other desired action)
    var updatedEquipment = {
        equipmentName: equipmentName,
        model: model,
        colour: colour,
        serialNumber: serialNumber,
        equipmentType: equipmentType,
        manufacturer: manufacturer,
        description: description
    };

    // Update the equipment in your storage mechanism (e.g., localStorage)
    var currentSerial = getSerialNumberFromURL();
    var index = storedEquipment.findIndex(function (equipment) {
        return equipment.serialNumber === currentSerial;
    });

    if (index !== -1) {
        storedEquipment[index] = updatedEquipment;
        localStorage.setItem('storedEquipment', JSON.stringify(storedEquipment));
        alert('Equipment details updated successfully!');
    } else {
        alert('Equipment not found. Update failed.');
    }

    // Disable editing and show the Edit button again
    document.querySelectorAll('input[type="text"], textarea').forEach(input => {
        input.setAttribute('readonly', 'readonly');
    });
    // After successfully updating the equipment, hide the "Clear" button
    document.getElementById('clearButton').style.display = 'none';
    
    // Show the "Edit" button
    document.getElementById('editButton').style.display = 'block';
    
    // Hide the "Update" button
    document.getElementById('updateButton').style.display = 'none';
}

function generateEquipmentTable() {
    var equipmentTable = document.querySelector('tbody');
    if(!equipmentTable)
        return;
    // Clear the table before populating it
    equipmentTable.innerHTML = '';

    // Loop through the stored equipment and add rows to the table
    storedEquipment.forEach(function (equipment) {
        var newRow = equipmentTable.insertRow(-1);
        var modelCell = newRow.insertCell(0);
        var typeCell = newRow.insertCell(1);
        var serialNumberCell = newRow.insertCell(2);

        var equipmentLink = document.createElement('a');
        equipmentLink.className = 'equipment-link';
        equipmentLink.href = 'equipment-details.html?serial=' + equipment.serialNumber;
        equipmentLink.textContent = equipment.model;

        modelCell.appendChild(equipmentLink);
        typeCell.textContent = equipment.equipmentType;
        serialNumberCell.textContent = equipment.serialNumber;
    });
}

// Call the function to generate the equipment table when the page loads
generateEquipmentTable();

// Function to retrieve the serial number from the URL parameter
function getSerialNumberFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('serial');
}

// Call the function to get the serial number
const serialNumber = getSerialNumberFromURL();

// EQUIPMENT VIEW
// Function to display stored equipment
function displayStoredEquipment() {
    var equipmentTable = document.querySelector('tbody');

    if(!equipmentTable)
        return;

    // Retrieve stored equipment from localStorage
    var storedEquipment = JSON.parse(localStorage.getItem('storedEquipment')) || [];

    // Loop through the stored equipment and add rows to the table
    storedEquipment.forEach(function (equipment) {
        var newRow = equipmentTable.insertRow(-1);
        var modelCell = newRow.insertCell(0);
        var typeCell = newRow.insertCell(1);
        var serialNumberCell = newRow.insertCell(2);

        // Create a link to view equipment details
        var equipmentLink = document.createElement('a');
        equipmentLink.className = 'equipment-link';
        equipmentLink.href = 'equipment-details.html?serial=' + equipment.serialNumber;
        equipmentLink.textContent = equipment.model;
    
        // Add the link to the Model cell
        modelCell.appendChild(equipmentLink);
    
        // Populate the cells with equipment details
        typeCell.textContent = equipment.equipmentType;
        serialNumberCell.textContent = equipment.serialNumber;
    
        // Store the equipment data as dataset attributes for each row
        newRow.dataset.model = equipment.model;
        newRow.dataset.equipmentType = equipment.equipmentType;
        newRow.dataset.serialNumber = equipment.serialNumber;
 });
}

// Call the function when the page has fully loaded
window.onload = function () {
    displayStoredEquipment();
    loadEquipmentDetails();
};
// Function to clear all stored equipment
function clearStoredEquipment() {
    localStorage.removeItem('storedEquipment');
}

// Call this function to clear the storage
//clearStoredEquipment();
const menuToggle = document.getElementById('menu-toggle');
const overlay = document.querySelector('.menu-overlay');
const body = document.body;

// Arrays to store colors, manufacturers, and cities
let colours = ["Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"];
let manufacturers = ["Honda", "Kohler", "Briggs & Stratton", "Kawasaki", "Subaru", "Generac", "Loncin", "Tecumseh", "Stihl", "Dewalt"];
let cities = ["Toronto", "Montreal", "Vancouver", "Hamilton", "Kingston", "Welland", "St.Catherines", "Mississauga", "Ottawa", "Brampton",
"Vaughan", "Windsor", "Kitchener", "London", "Châteauguay", "Drummondville", "Saint-Jérôme", "Chicoutimi - Jonquière", "Berwick"];

//FUNCTIONS FOR COLOURS SUPPORT PAGE
function addColour() {
    // Get the value entered for the new color
    let newColour = document.getElementById('newColour').value;

    // Check if the color already exists
    if(colours.includes(newColour)) {
        alert('This colour already exists!');
    } else {
        // Add to colours array
        colours.push(newColour);

        // Display an alert with all colors
        alert('Colours: ' + colours.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('newColour').value = '';
}

function editColour() {
    // Get the value entered for the new color
    let editColour = document.getElementById('editColour').value;

    // Check if the color already exists
    if(colours.includes(editColour)) {
        alert('This colour already exists!');
    } else {
        // Add to colours array
        colours.push(editColour);

        // Display an alert with all colors
        alert('Colours: ' + colours.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('editColour').value = '';
}

//FUNCTIONS FOR MANUFACTURER SUPPORT PAGE
function addManufacturer() {
    // Get the value entered for the new manufacturer
    let newManufacturer = document.getElementById('newManufacturer').value;

    // Check if the manufacturer already exists
    if(manufacturers.includes(newManufacturer)) {
        alert('This manufacturer already exists!');
    } else {
        // Add to manufacturers array
        manufacturers.push(newManufacturer);

        // Display an alert with all colors
        alert('Manufacturers: ' + manufacturers.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('newManufacturer').value = '';
}

function editManufacturer() {
    // Get the value entered for the new color
    let editManufacturer = document.getElementById('editManufacturer').value;

    // Check if the color already exists
    if(manufacturers.includes(editManufacturer)) {
        alert('This manufacturer already exists!');
    } else {
        // Add to colours array
        manufacturers.push(editManufacturer);

        // Display an alert with all colors
        alert('Manufacturer: ' + manufacturers.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('editManufacturer').value = '';
}

//FUNCTIONS FOR CITY SUPPORT PAGE
function addCity() {
    // Get the value entered for the new color
    let newCity = document.getElementById('newCity').value;

    // Check if the color already exists
    if(cities.includes(newCity)) {
        alert('This city already exists!');
    } else {
        // Add to colours array
        cities.push(newCity);

        // Display an alert with all colors
        alert('Cities: ' + cities.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('newCity').value = '';
}

function editCity() {
    // Get the value entered for the new color
    let editCity = document.getElementById('editCity').value;

    // Check if the color already exists
    if(cities.includes(editCity)) {
        alert('This city already exists!');
    } else {
        // Add to colours array
        cities.push(editCity);

        // Display an alert with all colors
        alert('Cities: ' + cities.join(', '));
    }
    // Clear the input for next entry
    document.getElementById('editCity').value = '';
}

//LOGIN FORM//
function submitForm() {
    // Get values from the form
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const province = document.getElementById('province').value;
    const postalCode = document.getElementById('postalCode').value;
    const phone = document.getElementById('phone').value;

    // Validate the values if needed

    // Construct the URL with query parameters
    const nextPageURL = `nextpage.html?firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&email=${encodeURIComponent(email)}&address=${encodeURIComponent(address)}&city=${encodeURIComponent(city)}&province=${encodeURIComponent(province)}&postalCode=${encodeURIComponent(postalCode)}&phone=${encodeURIComponent(phone)}`;

    // Redirect to the next page
    window.location.href = 'Report.html';
}

//REPAIRS PAGE//
// FILL REPAIR RECORD WITH CURRENT DATE
document.addEventListener('DOMContentLoaded', function () {
    // Get the current date in the format YYYY-MM-DD
    const currentDate = new Date().toISOString().split('T')[0];
  
    // Set the value of the date input to the current date
    document.getElementById('repairDateInput').value = currentDate;
  });

function addRecord() {
    // Get input values
    const customerName = document.getElementById('repairCustomerName').value;
    const equipmentName = document.getElementById('repairEquipmentName').value;
    const date = document.getElementById('repairDateInput').value;
    const problem = document.getElementById('problem').value;
    const status = document.getElementById('status').value;

    // Reference to table body
    const tableBody = document.getElementById('repairsTableBody');

    // Create a new row
    const newRow = document.createElement('tr');

    // Create cells for the row
    const customerNameCell = document.createElement('td');
    const equipmentNameCell = document.createElement('td');
    const dateCell = document.createElement('td');
    const problemCell = document.createElement('td');
    const statusCell = document.createElement('td');

    // Create a link for the customer name
    const customerLink = document.createElement('a');
    customerLink.href = 'repairs-tech.html?customer=' + customerName; // Replace with the actual URL of the page
    customerLink.textContent = customerName;

    // Set cell content
    customerNameCell.appendChild(customerLink);
    equipmentNameCell.textContent = equipmentName;
    dateCell.textContent = date;
    problemCell.textContent = problem;
    statusCell.textContent = status;

    // Append cells to the row
    newRow.appendChild(customerNameCell);
    newRow.appendChild(equipmentNameCell);
    newRow.appendChild(dateCell);
    newRow.appendChild(problemCell);
    newRow.appendChild(statusCell);

    // Append row to the table body
    tableBody.appendChild(newRow);
}


// Function to register repairs
function registerRepair(repair) {
    // Retrieve the existing stored repairs from localStorage
    var storedRepairs = JSON.parse(localStorage.getItem('storedRepairs')) || [];

    // Check for duplicates
    var isDuplicate = storedRepairs.some(function (storedItem) {
        return storedItem.customerName === repair.customerName;
    });

    if (!isDuplicate) {
        // Add the new repair to the array
        storedRepairs.push(repair);

        // Save updated repairs list back to localStorage
        localStorage.setItem('storedRepairs', JSON.stringify(storedRepairs));

        // Notify the user that the repair was registered
        alert('Repair successfully registered.');

    } else {
        // Notify the user that it's a duplicate
        alert('This serial number is already registered.');
    }
}

  var storedRepairs = [
    {
        customerName: 'Hillary',
        equipmentName: 'TRX XR',
        repairDate: '11-09-2023',
        repairProblem: 'Slight ticking noise when motor is running',
        repairStatus: 'Complete'

    },
    {
        customerName: 'Tom',
        equipmentName: 'MS',
        repairDate: '11-11-2023',
        repairProblem: 'Gear fell off',
        repairStatus: 'Ongoing Repair'
    },
    {
        customerName: 'Sally',
        equipmentName: 'HRN',
        repairDate: '11-15-2023',
        repairProblem: 'Wont turn on',
        repairStatus: 'Ongoing Repair'
    },
];

function searchRepairs(repair) {
    const selectedCustomer = document.getElementById("repairTableCustomerName").value;
    // Filter the repairs based on the selected customer name
    const filteredRepairs = storedRepairs.filter(rep => rep.customerName.toLowerCase() === selectedCustomer.toLowerCase());

    // Get the table body to populate the filtered repairs
    const repairsTableBody = document.getElementById("repairsTableBody");

    // Clear the table before populating with filtered data
    repairsTableBody.innerHTML = "";

    // Populate the table with the filtered repairs
    filteredRepairs.forEach(rep => {
        const row = repairsTableBody.insertRow();
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);
        const cell3 = row.insertCell(2);
        const cell4 = row.insertCell(3);
        const cell5 = row.insertCell(4);

        cell1.textContent = rep.customerName;
        cell2.textContent = rep.equipmentName;
        cell3.textContent = rep.repairDate;
        cell4.textContent = rep.repairProblem;
        cell5.textContent = rep.repairStatus;
    });
}

// Get the table body element
var repairsTableBody = document.getElementById('repairsTableBody');

// Loop through the storedRepairs array
for (var i = 0; i < storedRepairs.length; i++) {
    // Insert a new row at the end of the table
    var row = repairsTableBody.insertRow();

    // Insert cells in the row
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4)

    // Create a link for the customer name
    var customerLink = document.createElement('a');
    customerLink.href = './repairs-tech.html?customer=' + storedRepairs[i].customerName; // Replace 'your-page-url' with the actual URL of the page
    customerLink.textContent = storedRepairs[i].customerName;

    //add the link to cell
    cell1.appendChild(customerLink);

    // Add the data to the cells
    cell2.innerHTML = storedRepairs[i].equipmentName;
    cell3.innerHTML = storedRepairs[i].repairDate;
    cell4.innerHTMl = storedRepairs[i].repairProblem;
    cell5.innerHTML = storedRepairs[i].repairStatus;
}

// Pass over problem description to tech side
document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const problem = urlParams.get('problem');
    if (problem) {
        document.getElementById('problem').value = problem;
    }
});

window.onload = populateCustomers;
